package com.yasemin.mobil1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
/*
public class Ders extends AppCompatActivity {
    private String ders;
    private String not;

    public String getNot() {
        return not;
    }

    public void setNot(String not) {
        this.not = not;
    }

    public String getDers() {
        return ders;
    }

    public void setDers(String ders) {
        this.ders = ders;
    }

    public Ders(String ders,String not){
        this.ders = ders;
        this.not = not;
    }

    public interface CustomItemClickListener {
        void onItemClick(View v, int position);
    }


}*/
