package com.yasemin.mobil1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Kayit extends AppCompatActivity {

    private Button login;
    private EditText kullanici, sifre;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kayit);

        kullanici = findViewById(R.id.editKullanici);
        sifre = findViewById(R.id.editSifre);
        login = findViewById(R.id.buttonLogin);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(kullanici.getText().toString().equals("Admin")&&
                        sifre.getText().toString().equals("password")){
                    Intent myIntent = new Intent(Kayit.this,
                            MainActivity.class);
                    startActivity(myIntent);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Yanlış kullanıcı adı ve şifre girişi...",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
