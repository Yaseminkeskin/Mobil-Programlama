package com.yasemin.mobil1;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import java.util.ArrayList;
import java.util.List;

import static android.view.View.*;

public class MainActivity extends AppCompatActivity implements OnClickListener{

    private EditText ad, soyad, tc, telefon, dogumYeri;
    private Spinner gun, ay, yil;
    private ImageView foto;
    private Button kaydet, pp, temizle;
    private static final int SELECT_PICTURE = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ad = findViewById(R.id.textAd);
        soyad = findViewById(R.id.textSoyad);
        tc = findViewById(R.id.textTC);
        tc.setInputType(InputType.TYPE_CLASS_NUMBER);
        dogumYeri = findViewById(R.id.editDogumYeri);
        telefon = findViewById(R.id.editTel);
        foto = findViewById(R.id.imageView);
        pp = findViewById(R.id.buttonPP);
        temizle = findViewById(R.id.buttonTemizle);

        gun = findViewById(R.id.spinnerGun);
        List<String> listGun = new ArrayList<String>();
        for (int i = 1; i <= 31; i++) {
            listGun.add("" + i);
        }
        final ArrayAdapter<String> gunAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listGun);
        gunAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gun.setAdapter(gunAdapter);
        gun.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        ay = findViewById(R.id.spinnerAy);
        List<String> listAy = new ArrayList<String>();
        for (int i = 1; i <= 12; i++) {
            listAy.add("" + i);
        }
        final ArrayAdapter<String> ayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listAy);
        ayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ay.setAdapter(ayAdapter);
        ay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        yil = findViewById(R.id.spinnerYil);
        List<String> listYil = new ArrayList<String>();
        for (int i = 1960; i <= 2019; i++) {
            listYil.add("" + i);
        }
        final ArrayAdapter<String> yilAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listYil);
        yilAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yil.setAdapter(yilAdapter);
        yil.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        temizle.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ad.getText().clear();
                soyad.getText().clear();
                tc.getText().clear();
                dogumYeri.getText().clear();
                telefon.getText().clear();
                gun.setAdapter(gunAdapter);
                ay.setAdapter(ayAdapter);
                yil.setAdapter(yilAdapter);
                foto.setImageResource(0);
            }
        });





        pp.setOnClickListener((OnClickListener) this);
        handlePermission();

       /* Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.profil);
        Intent intnt = new Intent();
        intnt.setClass(MainActivity.this, Result.class);
        intnt.putExtra("resim", bitmap);
        startActivity(intnt);*/

        kaydet = findViewById(R.id.buttonKaydet);
        kaydet.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle b = new Bundle();

                Intent intent = new Intent(MainActivity.this, Result.class);

                b.putString("isim", ad.getText().toString());
                b.putString("soyisim", soyad.getText().toString());
                b.putString("tc", tc.getText().toString());
                b.putString("telefon", telefon.getText().toString());
                b.putString("dogumyeri", dogumYeri.getText().toString());

                intent.putExtras(b);
                startActivity(intent);

            }
        });
    }

    private void handlePermission() {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PermissionChecker.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, SELECT_PICTURE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case SELECT_PICTURE:
                for (int i = 0; i < permissions.length; i++) {
                    String permission = permissions[i];
                    if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        boolean showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, permission);
                        if (showRationale) {

                        } else {
                            showSettingsAlert();
                        }
                    } else {
                    }
                }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void showSettingsAlert() {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("App needs access to the storage.");
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Don't allow", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                openAppSettings();
            }
        });
    }

    private void openAppSettings() {
        Intent i = new Intent();
        i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.addCategory(Intent.CATEGORY_DEFAULT);
        i.setData(Uri.parse("package:" +getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        startActivity(i);
    }

    void openImageChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"),SELECT_PICTURE);
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, @Nullable final Intent data) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(resultCode == RESULT_OK){
                    if(requestCode == SELECT_PICTURE){
                        final Uri selectedımageUri = data.getData();
                        if(null != selectedımageUri){
                            foto.post(new Runnable(){
                                @Override
                                public void run() {
                                    foto.setImageURI(selectedımageUri);
                                }
                            });
                        }
                    }
                }
            }
        }).start();
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void onClick(View v){
        openImageChooser();
   }
}