package com.yasemin.mobil1;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Result extends AppCompatActivity {
    private TextView ad, soyad, TC, yas, telefon, dG;
    private ImageView image;
    private Button kaydet, derslerim;
   // private RecyclerView recycler_view;
    //private List<Ders> ders_list;
    
    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Bitmap bitmap = (Bitmap)this.getIntent().getParcelableExtra("resim");
        setContentView(R.layout.activity_result);
        //image = findViewById(R.id.imageProfil);
        //image.setImageBitmap(bitmap);



        ad = findViewById(R.id.textAd);
        soyad = findViewById(R.id.textSoyad);
        TC = findViewById(R.id.textTc);
        yas = findViewById(R.id.textTel);
        telefon = findViewById(R.id.textTel);
        dG = findViewById(R.id.textDogumYeri);
        derslerim = findViewById(R.id.buttonders);

        Bundle b = getIntent().getExtras();
        ad.setText(b.getCharSequence("isim"));
        soyad.setText(b.getCharSequence("soyisim"));
        TC.setText(b.getCharSequence("tc"));
        telefon.setText(b.getCharSequence("telefon"));
        dG.setText(b.getCharSequence("dogumyeri"));

      /* derslerim.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               recycler_view = findViewById(R.id.recycler_view);

               LinearLayoutManager layoutManager = new LinearLayoutManager(Result.this);

               layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
               layoutManager.scrollToPosition(0);

               recycler_view.setLayoutManager(layoutManager);

               ders_list = new ArrayList<Ders>();

               ders_list.add(new Ders("Mobil Programlama", "AA"));
               ders_list.add(new Ders("Veri İletişimi", "BA"));
               ders_list.add(new Ders("İstatistiksel Veri Analizi", "CB"));
               ders_list.add(new Ders("Assembly", "BB"));
               ders_list.add(new Ders("İşletmeye Giriş", "AA"));
               ders_list.add(new Ders("Biyoenformatiğe Giriş", "BB"));
               ders_list.add(new Ders("Yapay Zeka", "CC"));
               ders_list.add(new Ders("Ayrık Olay Simülasyonu", "DC"));
               ders_list.add(new Ders("Veri Yapıları ve Algoritmalar", "AA"));
               ders_list.add(new Ders("Sayısal İşaret İşleme", "BA"));



               SimpleRecyclerAdapter adapter_items = new SimpleRecyclerAdapter(ders_list, new Ders.CustomItemClickListener() {
                   @Override
                   public void onItemClick(View v, int position) {
                       Log.d("position", "Tıklanan Pozisyon:" + position);
                       Ders ders = ders_list.get(position);
                       Toast.makeText(getApplicationContext(),"pozisyon:"+" "+position+" "+"Ad:"+ders.getDers(),Toast.LENGTH_SHORT).show();
                   }
               });
               recycler_view.setHasFixedSize(true);

               recycler_view.setAdapter(adapter_items);

               recycler_view.setItemAnimator(new DefaultItemAnimator());
           }
       });*/

    }
}
