package com.yasemin.mobil1;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;
/*
public class SimpleRecyclerAdapter extends RecyclerView.Adapter<SimpleRecyclerAdapter.ViewHolder> {

        public static class ViewHolder extends RecyclerView.ViewHolder {

            public TextView ders;
            public TextView not;


            public ViewHolder(View view) {
                super(view);
                ders = (TextView)view.findViewById(R.id.ders);
                not = (TextView)view.findViewById(R.id.not);

            }
        }

        List<Ders> list_ders;
        Ders.CustomItemClickListener listener;
    public SimpleRecyclerAdapter(List<Ders> list_person, Ders.CustomItemClickListener listener) {

            this.list_ders = list_ders;
            this.listener = listener;
        }


    @Override
    public SimpleRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view, parent, false);
        final ViewHolder view_holder = new ViewHolder(v);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v, view_holder.getOldPosition());
            }
        });

        return view_holder;
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.ders.setText(list_ders.get(position).getDers());
        holder.not.setText(list_ders.get(position).getNot());

    }

    @Override
    public int getItemCount() {
        return list_ders.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }
}
*/